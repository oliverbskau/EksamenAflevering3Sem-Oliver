-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: eksamen3sem
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kandidat`
--

DROP TABLE IF EXISTS `kandidat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kandidat` (
  `kandidatid` int NOT NULL AUTO_INCREMENT,
  `kandidat_navn` varchar(255) DEFAULT NULL,
  `kandidat_stemmer` int NOT NULL,
  `partiid` int DEFAULT NULL,
  PRIMARY KEY (`kandidatid`),
  KEY `FKrjoc80bh91aj5063uy4lmnqjc` (`partiid`),
  CONSTRAINT `FKrjoc80bh91aj5063uy4lmnqjc` FOREIGN KEY (`partiid`) REFERENCES `parti` (`partiid`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kandidat`
--

LOCK TABLES `kandidat` WRITE;
/*!40000 ALTER TABLE `kandidat` DISABLE KEYS */;
INSERT INTO `kandidat` VALUES (1,'Johan Brink Jensen',105,1),(2,'Jørgen Dalsgaard',17,1),(3,'Kim Fischer',18,1),(4,'Frank Jensen',378,2),(5,'Olav Nielsen',63,2),(6,'Melissa Gilroy',67,2),(7,'Mille Renée Larsen',65,2),(8,'Sofie Exner',25,2),(9,'Christian Lorentzen',238,3),(10,'Anja Parbst Høst',16,3),(11,'Niels Fischer-Nielsen',106,3),(12,'Tina Haldan Gotthardsen',25,3),(13,'Tobias Tonel',17,3),(14,'Kurt Kirkegaard',27,3),(15,'Kenneth Lindenhorf',21,3),(16,'Karen Jeppesen',74,4),(17,'Stina Thøgersen',22,4),(18,'Erik Stoye',11,4),(19,'Niels Christian Nielsen',18,4),(20,'Henning Kjærsgaard',52,5),(21,'Willy Morgenstern',10,6),(22,'John Ditlev Sørensen',15,6),(23,'Erik Nørreby',168,7),(24,'Emi Lodal Malling',24,7),(25,'Anders Frey',49,7),(26,'Lars Christoffersen',93,7),(27,'Rikke Iversen',10,7),(28,'Dennis Feldberg',16,7),(29,'Emil Hoffmann Madsen',41,7),(30,'Lasse Harder Schousboe',104,8),(31,'Lisbet Petersen',5,8),(32,'Peter Bøgsted Knudsen',3,8),(33,'Mette Nørby Jensen',9,8),(34,'Lars Nielsen',3,8),(35,'Malene D Beck',8,8),(36,'Benjamin S Andersen',60,9),(37,'Lene Kaltwasser Leonhardt',10,9);
/*!40000 ALTER TABLE `kandidat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-20 10:38:56
